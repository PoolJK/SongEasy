/*
  Copyright � Grame 2007

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.
    
    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.
    
    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Grame Research Laboratory, 9, rue du Garet 69001 Lyon - France
    research@grame.fr

*/

#ifndef __TTransposeVisitor__
#define __TTransposeVisitor__

#include "exports.h"
#include "TNodeVisitor.h"

// using namespace std;

namespace MusicXML 
{

/*!
\addtogroup visitors
@{
*/

typedef int	Chromatic;
typedef int	Diatonic;

/*!
\brief A visitor that operates a diatonic transposition of a score.

	The TTransposeVisitor computes a diatonic transposition of
	a score. The transposition interval is specified as a number of chromatic
	steps, the simplest enharmonic diatonic transposition is automatically selected.
	
	The TTransposeVisitor can operate in 2 modes:
	- a standard transposing mode: where all the parts are transposed according 
	  to the specified interval
	- a transposing instrument mode: where the transposition is applied to a normalized
	  score, i.e. a score as written for a non-transposing instrument. It means that
	  a 3 interval applied to a score already transposed with a 2 interval will only
	  apply an additional 1 interval.	

\warning this visitor is intended to operate on partwise scores only
\todo transposing ornaments elements
*/
class VEXP TTransposeVisitor : public TNodeVisitor {
    protected:
		Chromatic	fChromaticSteps;	// the target transposing interval
		Chromatic	fCurrentSteps;		// the actual transposing interval (normalized to 0-11 and modified when the score is already transposed)

		Diatonic	fDiatonicSteps;		// the target diatonic transposing interval
		Diatonic	fCurrentDiatonics;	// the actual diatonic transposing interval

		int		fOctaveChange;			// the target octave change compute from fChromaticSteps
		int		fCurrentOctaveChange;	// the actual octave change (in case of already transposed score)

		int		fKeySign;			// the target key signature
		int		fCurrentKeySign;	// the current key signature
		int		fTransposeKey;		// the key sign corresponding to a possible transpose element

		bool	fGenerateTransposeElement;
		int		fMeasureNum;
		int		fTransposeVisited;

		virtual void changePitch ( SPitch& elt );
		// sets a transpose element to the current transpose and adjust current settings
		virtual void setTranspose ( STranspose& dst );
		virtual void setAccident ( SAccidental& acc, float alter  );
		
    public:
		TTransposeVisitor(int steps, bool generateTransposeElement);
		virtual ~TTransposeVisitor();


		/*! computes an octaves count from a chromatic interval
			\param steps a chromatic steps count
			\return the count of octaves
		*/
		static int  getOctave ( Chromatic steps ) {	return steps/12; }

		/*! computes a step number wihin an octave
			\param steps a chromatic steps count
			\return the step number within an octave
		*/
		static Chromatic  getOctaveStep ( Chromatic steps ) {	return steps%12; }


		/*! computes a key sign corresponding to a chromatic degree 
			\param steps a chromatic step
			\return a numeric key signature representing a number of sharps when positive
			and a number of flats when negative
		*/
		static int  getKey ( Chromatic steps );

		/*! computes a diatonic interval corresponding to a chromatic interval and a key signature 
			\param steps a chromatic steps count
			\param key a key signature
			\return the count of corresponding diatonic steps
		*/
		static Diatonic  getDiatonics ( Chromatic steps, int key );

		/*! gives a note accidental according to a key signature
			\param pitch a diatonic pitch (where C=1)
			\param key the key signature expressed as a number of sharps when > 0 or flats when < 0
			\return an accidental as a positive value for sharps and negative for flats
		*/
		static int getAccidental ( Diatonic pitch, int key );

		/*! increment a diatonic pitch and returns the corresponding number of chromatic steps
			\param pitch a diatonic pitch value (where C=1)
			\param octave the octave number on input and the possible new octave number on output
			\return the corresponding chromatic steps count
		*/
		static int incPitch ( Diatonic& pitch, int& octave );

		/*! decrement a diatonic pitch and returns the corresponding number of chromatic steps
			\param pitch a diatonic pitch value (where C=1)
			\param octave the octave number on input and the possible new octave number on output
			\return the corresponding chromatic steps count
		*/
		static int decPitch ( Diatonic& pitch, int& octave );

		/*! transpose a pitch expressed as a diatonic value + alteration + octave
			\param pitch on input a diatonic pitch value (where C=1), on output the new pitch value
			\param alter on input the accidental value, on output the new accidental value
			\param octave on input the octave number, on output the new octave number
			\param steps the transposing interval expressed in chromatic steps
			\return the corresponding diatonic steps count
		*/
		static int transposePitch ( Diatonic& pitch, float& alter, int& octave, Chromatic steps );

		virtual void visiteEnter ( SKey& elt );
		virtual void visiteEnter ( SNote& elt );
		virtual void visiteEnter ( SOrnament& elt );
		virtual void visiteEnter ( SWavyLine& elt );
		virtual void visiteEnter ( SMordentOrnament& elt );
		virtual void visiteEnter ( STrillOrnament& elt );
		virtual void visiteEnter ( SOtherOrnament& elt );
		virtual void visiteEnter ( STranspose& elt );
		virtual void visiteEnter ( SPWMeasure& elt );
		virtual void visiteEnter ( SPWPart& elt );

		virtual void visiteLeave ( SAttributes& elt );		
};
typedef SMARTP<TTransposeVisitor> STransposeVisitor;
/*! @} */

} // namespace MusicXML


#endif
