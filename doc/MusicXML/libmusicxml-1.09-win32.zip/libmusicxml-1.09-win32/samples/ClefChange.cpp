/*

  Copyright (C) 2003  Grame
  Grame Research Laboratory, 9 rue du Garet, 69001 Lyon - France
  research@grame.fr

  This file is provided as an example of the MusicXML Library use.
  It shows how to read and write xml files. It also gives a concrete
  example of how to browse and modify the memory representation of
  a score.
  
*/


#include <iostream>

#include "LibMusicXML.h"

using namespace std;
using namespace MusicXML;

//------------------------------------------------------------------------
//
// This is an example of a visitor implementation. Visitors allows
// to browse the memory representation of a score. Two basic visitors
// are provided by the library:
//  - a TRoutedVisitor which is a visitor that provides a path for 
//    traversing the score tree (see the library documentation for the
//    path description). 
//  - a TScoreVisitor which is a visitor that does nothing: objects
//    that derive from TScoreVisitor must implement a path for traversing
//    the score tree. This may be necessary only for non-standard way
//    of browsing the score. 
// The ClefModifier visitor has no special requirement concerning the path
// for traversing the tree and therefore derives from TRoutedVisitor.
// It is only interested in TClef objects and therefore, only overrides 
// the corresponding method.
//
//------------------------------------------------------------------------
class ClefModifier : public TRoutedVisitor {

    public:
		// constructor is initialized with the transposing interval
		ClefModifier(int clef, int line) : fClef(clef), fLine(line) {}
		virtual ~ClefModifier() {}
		void visite ( SClef& elt );

	private:
		int	fClef, fLine;
};

//------------------------------------------------------------------------
// The raw transposition implementation.
//------------------------------------------------------------------------
void ClefModifier::visite (SClef& clef) {
	clef->setSign(fClef);
	clef->setLine(fLine);
}

//------------------------------------------------------------------------
static int getClef (char* arg, int& line) 
{
	int n = arg[1];
	if (n > 0) n -= '0';
	if (n > 5) TClef::undefined;
	switch (arg[0]) {
		case 'G':
			line = n ? n : 2;
			return TClef::G;
		case 'F':
			line = n ? n : 4;
			return TClef::F;
		case 'C':
			line = n ? n : 3;
			return TClef::C;
	}
	return  TClef::undefined;
}

//------------------------------------------------------------------------
int usage (char* name) 
{
    cerr << "usage: " << name << " <Clef> <file>" << endl;
	cerr << "       where <clef> is [G | F | C] optionally followed by a line number (between 1 to 5)" << endl;
	exit(1);
}

//------------------------------------------------------------------------
int main (int argc, char * argv[]) 
{
    if (argc != 3) usage (argv[0]);
	int line, clef = getClef(argv[1], line);
	if (clef < 1) usage (argv[0]);
	
	// use of a TMusicXMLFile object to read and write xml files
	TMusicXMLFile file;
	// reads the file (file name is readed from the command line)
	SScore score = file.read(argv[2]);
	if (score) {
		// declares a ClefModifier object
		ClefModifier cmod(clef, line);
		// ask the score to accept the modifier
		score->accept(cmod);
		// and finally writes the result on the standard output
		// 'cout' could be replaced by a file as well
		file.write (score, cout);
	}
	else cerr << "cannot read file \"" << argv[2] << "\"" << endl;
	return 0;
}


