/*

  Copyright (C) 2007  Grame
  Grame Research Laboratory, 9 rue du Garet, 69001 Lyon - France
  research@grame.fr

  This file is provided as an example of the MusicXML Library use.
  It shows how to read and write xml files. It also gives a concrete
  example of how to browse and modify the memory representation of
  a score.
  
*/

#include <iostream>

#include "LibMusicXML.h"
#include "TUnrolledVisitor.h"

using namespace std;
using namespace MusicXML;

//------------------------------------------------------------------------
static void usage(char * name)
{
	cerr << "usage: " << name << " <file>" << endl;
	exit(1);
}

//------------------------------------------------------------------------
int main (int argc, char * argv[]) 
{
    if (argc != 2) usage(argv[0]);

	char *path = argv[1];
	// use of a TMusicXMLFile object to read and write xml files
	TMusicXMLFile file;
	// reads the file (file name is readed from the command line)
	SScore score = file.read(path);
	if (score) {
		TNodeVisitor dummyVisitor;
		TUnrolledVisitor unrolledVisitor(&dummyVisitor);
		score->accept(unrolledVisitor);
		const list<TSection>& lst = unrolledVisitor.GetSectionList();		
		list<TSection>::const_iterator it;
		int i=1, size=lst.size();
		for (it = lst.begin(); it != lst.end(); it++) {
			TSection section = *it; // a pair of [begin, end] measure number
			cout << "section " << i++ << "/" << size << ": from measure " << section.first << " to " << section.second << endl;
		}
	}
	else cerr << "cannot read file \"" << path << "\"" << endl;
	return 0;
}


