/*
  Copyright � Grame 2003,2007

  This library is free software; you can redistribute it and modify it under
  the terms of the GNU Library General Public License as published by the
  Free Software Foundation version 2 of the License, or any later version.

  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public License
  for more details.

  You should have received a copy of the GNU Library General Public License
  along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Grame Research Laboratory, 9, rue du Garet 69001 Lyon - France
  research@grame.fr
  
*/

#include "TMusicXMLFile.h"
#include "TXML2GuidoVisitor.h"
#include "TScore.h"
//#include "GuidoChecker.h"

#include <iostream>

using namespace MusicXML;
using namespace std;

void usage() {
	cerr << "usage: musicXML2guido [options]  <musicxml file>" << endl;
	cerr << "option: --withbars inhibit guido autobarlines and generates barlines" << endl;
	exit(1);
}

int main (int argc, char * argv[]) 
{
	bool generateBars = false;
	char * file = argv[1];
	if (argc == 3) {
		if (!strcmp(argv[1], "--withbars"))
			generateBars = true;
		else usage();
		file = argv[2];
	}
	else if (argc != 2) usage();

    TXML2GuidoVisitor c(true, true, generateBars);
    TMusicXMLFile reader;
    SScore score = reader.read(file);
    if (score == NULL) {
        cerr << "Parse error" << endl;
        return 0;
    }
	score->accept(c);
	Sguidoelement gmn = c.current();
//	guidochecker gc;
//	gmn->accept(gc);
	cout << gmn << endl;
    return 0;
}

