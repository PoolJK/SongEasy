/*

  Copyright (C) 2007  Grame
  Grame Research Laboratory, 9 rue du Garet, 69001 Lyon - France
  research@grame.fr

  This file is provided as an example of the MusicXML Library use.
  It shows how to read and write xml files. It also gives a concrete
  example of how to browse and modify the memory representation of
  a score.
  
*/

#include <iostream>

#include "LibMusicXML.h"
#include "TTransposeVisitor.h"
#include "TRolledVisitor.h"

using namespace std;
using namespace MusicXML;

//------------------------------------------------------------------------
static void usage(char * name)
{
	cerr << "usage: " << name << " [options] <interval> <file>" << endl;
	cerr << "options: -t generate a transpose element" << endl;
	exit(1);
}

//------------------------------------------------------------------------
int main (int argc, char * argv[]) 
{
	bool generateTransposeElement=false;
	int i=1;

	if (argc == 4) {
		if (!strcmp(argv[1], "-t")) generateTransposeElement=true;
		else usage(argv[0]);
		i=2;
	}
    else if (argc != 3) usage(argv[0]);

	// transposing interval is readed from the command line
	int interval = atoi(argv[i]);
	char *path = argv[i+1];
	// use of a TMusicXMLFile object to read and write xml files
	TMusicXMLFile file;
	// reads the file (file name is readed from the command line)
	SScore score = file.read(path);
	if (score) {
		// declares a TTransposerVisitor
		TTransposeVisitor transposer(interval, generateTransposeElement);
		// declares a TRolledVisitor object
		TRolledVisitor rv(&transposer);
		// ask the score to accept the visitor
		score->accept(rv);
		// and finally writes the result on the standard output
		file.write (score, cout);
	}
	else cerr << "cannot read file \"" << path << "\"" << endl;
	return 0;
}


